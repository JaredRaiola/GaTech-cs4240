
import java.util.HashMap;


public class TigerSymbolTable {

    private HashMap<String, ScopeStructure> programTable;


    public TigerSymbolTable() {

        this.programTable = new HashMap<String, ScopeStructure>();

    }


}


