
public class ScopeStructure {

    private Scope current_scopes;

    // purpose is to be able to easily change scopes!


    public ScopeStructure() {

    }


}


